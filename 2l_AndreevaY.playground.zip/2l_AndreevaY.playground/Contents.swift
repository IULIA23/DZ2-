// DZ2_AndreevaY.

import Foundation

// 1 задание. Написать функцию, которая определяет, четное число или нет.

func numberDivider (number1: Int, divider: Int) -> Bool {
    var isRemainder = false
    if number1 % 2 == 0 {
        isRemainder = true
    }
    return isRemainder
}

// 2 задание. Написать функцию, которая определяет, делится ли число без остатка на 3.

func numberDivider (number2: Int, divider: Int) -> Bool {
    var isRemainder = false
    if number2 % 3 == 0 {
        isRemainder = true
    }
    return isRemainder
}
// 3 задание.  Создать возрастающий массив из 100 чисел.

let numbers3 = Array(1...100)
    print(numbers3)


// 4 задание. Удалить из этого массива все четные числа и все числа, которые не делятся на 3.

var numbers4 = [Int]()
for i in 1...100 {
if i % 3 == 0 {
    numbers4.append(i)
  }
}
    print(numbers4)

